from app import app
from flask import Flask, Response, render_template
import requests


# ZIP_URL = "https://cdimage.debian.org/debian-cd/current/amd64/iso-dvd/debian-13.5.0-amd64-DVD-1.iso"
ZIP_URL = "https://github.com/jquery/jquery/archive/refs/heads/main.zip"
VIDEO_URL = "https://videos.pexels.com/video-files/30282510/12987323_2560_1440_30fps.mp4"

@app.route("/test")
def test():
    return render_template("mod_1/test.html")

@app.route("/video")
def video_page():
    return render_template("video.html")

def generate_video_stream():
    try:
        response = requests.get(VIDEO_URL, stream=True)
        response.raise_for_status()

        for chunk in response.iter_content(chunk_size=256 * 256):
            if chunk:
                yield chunk

    except requests.exceptions.RequestException as e:
        print("Video streaming error:", e)
        yield b""

@app.route("/stream-video")
def stream_video():
    return Response(
        generate_video_stream(),
        content_type="video/mp4"
    )

@app.route("/download")
def download():

    file = requests.get(
        ZIP_URL,
        stream=True
    )

    return Response(
        file.iter_content(chunk_size=1024),
        content_type="application/zip"
    )

app.run(debug=True)