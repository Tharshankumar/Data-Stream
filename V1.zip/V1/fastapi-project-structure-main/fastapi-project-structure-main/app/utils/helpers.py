# Utility functions or helpers
