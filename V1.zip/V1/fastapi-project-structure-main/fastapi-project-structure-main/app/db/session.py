# Database session configuration
