from fastapi import FastAPI
from fastapi.responses import StreamingResponse
import requests

app = FastAPI()

ZIP_URL = "https://github.com/jquery/jquery/archive/refs/heads/main.zip"
VIDEO_URL = "https://videos.pexels.com/video-files/30282510/12987323_2560_1440_30fps.mp4"


def stream_remote_file(url: str, chunk_size: int):
    with requests.get(url, stream=True) as response:
        response.raise_for_status()
        for chunk in response.iter_content(chunk_size=chunk_size):
            if chunk:
                yield chunk


@app.get("/stream-video")
def stream_video():
    return StreamingResponse(
        stream_remote_file(VIDEO_URL, chunk_size=256 * 256),
        media_type="video/mp4",
    )


@app.get("/download")
def download():
    return StreamingResponse(
        stream_remote_file(ZIP_URL, chunk_size=1024),
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=jquery-main.zip"},
    )
