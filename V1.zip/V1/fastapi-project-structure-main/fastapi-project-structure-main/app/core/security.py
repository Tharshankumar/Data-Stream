# Authentication and security functions
